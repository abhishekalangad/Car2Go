<?php
include("connectionw.php");
$link=$_POST['link'];
$date=$_POST['date'];
$time=$_POST['time'];

echo $sql="INSERT INTO link (link,`date`,`time`) VALUES ('$link','$date','$time')";
$result=mysqli_query($con,$sql);

if($result==1)
{
    echo "success";
    header("location:online.php");
}
else
{
 echo "failed";
}

?>