<?php
include("connectionw.php");
$link=$_POST['link'];
$date=$_POST['date'];
$time=$_POST['time'];

$sql="INSERT INTO record (link,`date`,`time`) VALUES ('$link','$date','$time')";
$result=mysqli_query($con,$sql);

if($result==1)
{
    echo "success";
    header("location:record.php");
}
else
{
 echo "failed";
}

?>