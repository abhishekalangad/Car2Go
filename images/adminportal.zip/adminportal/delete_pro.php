<?php
include("connectionw.php");

if(isset($_POST['delete']))
{
 
$id=$_POST['id'];

  $sql3="DELETE FROM link WHERE id=$id";

 
$result=mysqli_query($con,$sql3);

if(result==1)


{
    header("Location:online.php");

}

else
{
    header("Location:online.php");
}


}



if(isset($_POST['delete1']))
{
 
$id=$_POST['id'];

  $sql3="DELETE FROM signup WHERE id=$id";

 
$result=mysqli_query($con,$sql3);

if(result==1)


{
    header("Location:inbox.php");

}

else
{
    header("Location:inbox.php");
}


}

if(isset($_POST['delete2']))
{
 
$id=$_POST['id'];

  $sql3="DELETE FROM record WHERE id=$id";

 
$result=mysqli_query($con,$sql3);

if(result==1)


{
    header("Location:record.php");

}

else
{
    header("Location:record.php");
}


}
?>
