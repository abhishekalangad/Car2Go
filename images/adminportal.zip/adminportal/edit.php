<!DOCTYPE html>
<html>
  <head>
    <title>edit page</title>
  </head>
<style>
body {
  font-family: Arial;
}
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=email] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=image] {
  width: 10%;
  padding: 12px 20px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 100%;
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>
  
<!-- Mainly scripts -->
<script src="js/jquery.metisMenu.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<!-- Custom and plugin javascript -->
<link href="css/custom.css" rel="stylesheet">
<script src="js/custom.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});
			

			
		});
		</script>


<body>
  <div id="wrapper">
    <!----->
     <nav class="navbar-default navbar-static-top" role="navigation">
          <div class="navbar-header">
             <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                 <span class="sr-only">Toggle navigation</span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
             </button>
            <h1> <a class="navbar-brand" href="index.html">Admin</a></h1>         
      </div>
    <div class=" border-bottom">
       
  
    
         <!-- Brand and toggle get grouped for better mobile display -->
  
    <!-- Collect the nav links, forms, and other content for toggling -->
     <div class="drop-men" >
         <ul class=" nav_1">
            
         
       
            
         </ul>
      </div><!-- /.navbar-collapse -->
   <div class="clearfix">
    
  </div>
 
     <div class="navbar-default sidebar" role="navigation">
             <div class="sidebar-nav navbar-collapse">
             <ul class="nav" id="side-menu">
     
                  <li>
                     <a href="inbox.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Students</span> </a>
                 </li>
                 <li>
                     <a href="online.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Online Link</span> </a>
                 </li>
                 <li>
                     <a href="record.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Record Link</span> </a>
                 </li>
                 <li>
                  
                     <a href="logout.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Logout</span> </a>
                 </li>
                
                
        
             </ul>
            
         </div>
   </div>
</nav>
<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">
   <div class="banner">
    <h3 style="text-align: center;">
   Edit Student Details
    </h3>
</div>
    
     <div class="inbox-mail">
	
        <!-- tab content -->
        <div class="col-md-12 tab-content tab-content-in">
        <div class="tab-pane active text-style" id="tab1">
          <div class="inbox-right">
            <div class="mailbox-content" style="overflow-x: auto">
                <div class="mail-toolbar clearfix">
                    <form action="update.php" method="POST">
             


                    <?php
                    $id=$_GET['id'];
 
 include ("connectionw.php");
 $sql= "select * from signup WHERE id='$id'";
 $result=mysqli_query($con,$sql);
 $i=0;
  $row=mysqli_fetch_array($result);
 
     
 ?>
                        
                        <label for="name"> Name</label>
                        <input type="hidden"  name="id" placeholder="Student name" value="<?php echo $row['id'];?>" required>
                        <input type="text"  name="name" placeholder="Student name" value="<?php echo $row['name'];?>" required>
                    
                        
                        <label for="myusername"> Name</label>
                        <input type="email"  name="myusername" placeholder="Student email" value="<?php echo $row['username']?>" required>
                        
                        <label for="phone"> Phone number</label>
                        <input type="text"  name="phone" placeholder="phone number" value="<?php echo $row['phone']?>" required>
                        
                        <label for="mypassword"> Password</label>
                        <input type="text"  name="mypassword" placeholder="Student password" value="<?php echo $row['password']?>" required>
                        
                        <input type="submit" value="Submit">
                      </form>
                      </div>
                      </div>




          </div>
          </div>
          </div>
          </div>
          </div>
</div>
</div>

</body>
</html>