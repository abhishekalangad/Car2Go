<?php
session_start();
include('connectionw.php');

$idd3=$_SESSION['id'];
echo $sql3="UPDATE `signup` SET `status` = '0' WHERE `signup`.`id` = $idd3";
$res3=mysqli_query($con,$sql3);
unset($_SESSION['mypassword']);
unset($_SESSION['id']);
session_destroy();
header("Location:inbox.php");
?>





