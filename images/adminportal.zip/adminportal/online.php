<!DOCTYPE HTML>
<html>
<head>
<title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Inbox :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>
  
<!-- Mainly scripts -->
<script src="js/jquery.metisMenu.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<!-- Custom and plugin javascript -->
<link href="css/custom.css" rel="stylesheet">
<script src="js/custom.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});
			

			
		});
		</script>
<style>
.collapsible {
 background: #ffffff;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
}

.active, .collapsible:hover {
  
}

.content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
 
}
.collapsible {
 background: #ffffff;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
}

.active, .collapsible:hover {
  
}

.content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
 
}
</style>
</head>
<body>
<div id="wrapper">
       <!----->
        <nav class="navbar-default navbar-static-top" role="navigation">
             <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <h1> <a class="navbar-brand" href="index.html">Admin</a></h1>         
			   </div>
			 <div class=" border-bottom">
        	
     
       
            <!-- Brand and toggle get grouped for better mobile display -->
		 
		   <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="drop-men" >
		        <ul class=" nav_1">
		           
		    		
					
		           
		        </ul>
		     </div><!-- /.navbar-collapse -->
			<div class="clearfix">
       
     </div>
	  
		    <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
				
                     <li>
                        <a href="inbox.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Students</span> </a>
                    </li>
                    <li>
                        <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Online Link</span> </a>
                    </li>
                    <li>
                        <a href="record.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Record Link</span> </a>
                    </li>
                    <li>
                        <a href="lout.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Logout</span> </a>
                    </li>
                   
                   
					 
                </ul>
            </div>
			</div>
        </nav>
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     <div class="banner">
		    	<h2>
				Online Class Link
				</h2>
		    </div>
		<!--//banner-->
 	<!--grid-->
 	 <div class="inbox-mail">
	
<!-- link content -->
<div class="col-md-12 tab-content tab-content-in" >
<div class="tab-pane active text-style" id="tab1">
  <div class="inbox-right">
    <div class="mailbox-content" style="overflow-x: auto">
         <div class="mail-toolbar clearfix">
          <form action="add_link_pro.php" method="POST" >
            
            <input type="text" name="link" placeholder="Paste Link Here.." required >
            <input type="date" name="date"  required >
            <input type="time" name="time"  required >
         
            <input type="submit"  name="submit" value="submit "style=" width:  100px; margin-left: 270px;background-color: green; font-size: 15px; color: #fff;
             border: none; outline: none; padding: 0.5em 1.5em; border-radius: 4px;" class="collapsible"></input>
         </form>
         </div>
    </div>
    <table class="table">
      <tbody>
          <tr >
            <th >
                 
              Link
            </th>
             
             <th>logtime</th>
             <th>date</th>
             <th>time</th> 
            
               
          </tr>
          <tr class="table-row">
        
          <?php
 
 include ("connectionw.php");
 $sql= "select * from link";
 $result=mysqli_query($con,$sql);
 $i=0;
 while( $row=mysqli_fetch_array($result))
 {
     $i++;
 ?>
 <tr>
     <td><?php echo $row['link'];?></td> 
     <td><?php echo $row['logtime'];?></td> 
     <td><?php echo $row['date'];?></td>  
    <td><?php echo $row['time'];?></td> 
    <td >
    <form action="delete_pro.php" method="POST" >
      <input type="hidden" name="id" value="<?php echo $row['id'];?>">
      <input type="submit" name="delete" value="DELETE"  class="btn btn-xs btn-danger" 
 style="width: 80px; float:right; margin-right: 80px; font-size: 1em; color: #fff; border: none; outline: none; padding: 5px; border-radius: 4px;"  value="<?php echo $row['id'];?>">
 
 </form>
 </td>
 </tr>
<?php 
 }            
 ?>           

          </tr>
         <!-- <tr class="table-row">
          <td >
            <h5>https://www.w3schools.com/w3css/w3css_templates.asp</h5>
          </td>
              
               <td >
 <a href="delete.php?id=$id"><span class="btn btn-xs btn-danger" style="width: 80px;  font-size: 1em; margin-right: 80px; float:right; color: #fff; border: none; outline: none; padding: 5px; border-radius: 4px;"><b>DELETE</b></span></a>
                  
              </td>
          </tr> -->
          

      </tbody>
  </table>
  </div>
  </div>
  </div>
  </div>
        </div> 
</div>
</div>

<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
coll[i].addEventListener("click", function() {
this.classList.toggle("active");
var content = this.nextElementSibling;
if (content.style.display === "block") {
  content.style.display = "none";
} else {
  content.style.display = "block";
}
});
}
</script>  
<!---->
<!--scrolling js-->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!--//scrolling js-->
</body>
</html>