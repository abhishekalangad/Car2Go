<?php
include("connectionw.php");

   $n=$_POST['name'];
   $u=$_POST['myusername'];
   $ph=$_POST['phone'];
   $p=$_POST['mypassword'];
   
   


echo $sql1="INSERT INTO  signup (`name`,username,phone,`password`) VALUES ('$n','$u','$ph','$p')";

$res1=mysqli_query($con,$sql1);

if($res1==1)
{
	echo "success";
   header("Location:inbox.php");
	
	}

?>

   