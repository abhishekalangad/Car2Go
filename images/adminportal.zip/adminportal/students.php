<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="signup_pro.php" method="POST">
  <h2>students</h2>  
<table cellpadding="2" cellspacing="4" border="2">
   <tr> <th>slno</th><th>name</th><th>phone</th><th>username</th><th>password</th><th>edit</th><th>update</th><th>delete</th</tr>
 
    
 
<?php
 
 include ("connectionw.php");
 $sql= "select * from signup";
 $result=mysqli_query($con,$sql);
 $i=0;
 while( $row=mysqli_fetch_array($result))
 {
     $i++;
 ?>
     <tr>
     
     
     <td><?php echo $i; ?></td>
     <td><?php echo $row['name'];?></td>
    
    
     <td><?php echo $row['phone'];?></td>
    
    <td><?php echo $row['username'];?></td>
    <td><?php echo $row['password'];?></td>
    <td><a href=""><?php  echo "edit" ?></a> </td>
<td><a href=""><?php echo "update"; ?></a></td>
<td><a href=""><?php echo "delete"?></a></td> 
     
     </tr>
     <?php
 }
 ?>




</table>
</form>
</html>
