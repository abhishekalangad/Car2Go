<?php
include("connectionw.php");

$id=$_POST['id'];
$n=$_POST['name'];
$u=$_POST['myusername'];
$ph=$_POST['phone'];
$p=$_POST['mypassword'];


 $sql3="UPDATE signup SET `name`='$n', username='$u',phone='$ph', `password`='$p' WHERE id='$id'";
$result=mysqli_query($con,$sql3);
header("Location:inbox.php");
?>








